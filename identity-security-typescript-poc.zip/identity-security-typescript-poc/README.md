# Identity Security TypeScript POC

A small TypeScript/Node.js demonstration of identity and API-security patterns relevant to modern OAuth/OIDC and digital-identity systems.

## Demonstrates

- TypeScript + Node.js API
- JWT/JWS verification with a local JWKS
- Issuer, audience, expiration and JTI validation
- Authentication middleware
- Security headers
- Simple replay-protection example using JTI tracking
- Verifiable Credential issuer / holder / verifier concepts as a non-production demo

> This is a learning/demo project. It contains no client code, production credentials, or proprietary information.

## Run

```bash
npm install
npm run dev
```

The API starts on `http://localhost:3000`.

## Endpoints

- `GET /health`
- `GET /protected` — requires a valid demo JWT
- `GET /vc-model` — shows the simplified VC data model used by the demo

## Security notes

The demo intentionally validates common JWT claims such as `iss`, `aud`, `exp`, and `jti`. Production systems should also use a trusted identity provider, secure key storage, TLS, rate limiting, persistent replay protection, monitoring, and carefully managed key rotation.
