# Architecture Notes

```text
Client
  |
  | Bearer access token
  v
Node.js / TypeScript API
  |
  +--> HTTPS/security headers
  |
  +--> JWT/JWS verification
  |      +--> signature algorithm
  |      +--> issuer
  |      +--> audience
  |      +--> expiration
  |      +--> JTI
  |
  +--> replay protection example
  |
  +--> protected application resource
```

## Identity concepts

The repository also includes a small conceptual issuer/holder/verifier model to illustrate how a digital credential can carry claims separately from an application's authentication token.

This is intentionally a compact learning POC rather than a claim of production Verifiable Credential implementation.
