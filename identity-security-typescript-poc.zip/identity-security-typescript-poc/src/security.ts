import { createLocalJWKSet, jwtVerify, type JWTPayload } from "jose";

const issuer = "https://demo.identity.local";
const audience = "identity-security-demo";

// Demo public JWK. In production this would come from a trusted JWKS endpoint
// and would be cached with an explicit rotation strategy.
const jwks = createLocalJWKSet({
  keys: [
    {
      kty: "EC",
      crv: "P-256",
      x: "demo-public-key-placeholder",
      y: "demo-public-key-placeholder",
      kid: "demo-key-1",
      alg: "ES256",
      use: "sig"
    }
  ]
});

const usedJtis = new Set<string>();

export async function verifyAccessToken(token: string): Promise<JWTPayload> {
  const result = await jwtVerify(token, jwks, {
    issuer,
    audience,
    algorithms: ["ES256"]
  });

  const jti = result.payload.jti;
  if (!jti) {
    throw new Error("Missing jti claim");
  }

  if (usedJtis.has(jti)) {
    throw new Error("Replay detected: token jti has already been used");
  }

  usedJtis.add(jti);
  return result.payload;
}
