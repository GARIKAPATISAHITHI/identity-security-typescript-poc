import express from "express";
import helmet from "helmet";
import { verifyAccessToken } from "./security.js";

const app = express();
const port = Number(process.env.PORT ?? 3000);

app.use(express.json());
app.use(helmet());

app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "identity-security-demo" });
});

app.get("/protected", async (req, res) => {
  const header = req.header("authorization");

  if (!header?.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Bearer token required" });
  }

  try {
    const token = header.slice("Bearer ".length);
    const claims = await verifyAccessToken(token);

    return res.json({
      message: "Authenticated request",
      subject: claims.sub,
      issuer: claims.iss,
      audience: claims.aud
    });
  } catch (error) {
    return res.status(401).json({
      error: "Invalid access token",
      detail: error instanceof Error ? error.message : "verification failed"
    });
  }
});

app.get("/vc-model", (_req, res) => {
  res.json({
    model: "issuer-holder-verifier",
    credential: {
      type: ["VerifiableCredential", "DemoLoyaltyCredential"],
      issuer: "did:web:demo.example",
      credentialSubject: {
        id: "did:example:holder",
        loyaltyTier: "gold"
      }
    },
    note: "Conceptual demo model; not a production W3C VC implementation."
  });
});

app.listen(port, () => {
  console.log(`Identity security demo running on http://localhost:${port}`);
});
